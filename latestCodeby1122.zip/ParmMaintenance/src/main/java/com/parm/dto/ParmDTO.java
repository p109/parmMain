package com.parm.dto;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.springframework.jdbc.core.RowMapper;
import com.parm.entity.Parm;

public class ParmDTO  implements RowMapper<Parm>{

	
	String type="";
	String exception=null;
	public ParmDTO(String type,String Exception) {
		super();
		this.type = type;
		this.exception = Exception;
	}
	public ParmDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public Parm mapRow(ResultSet rs, int rowNum) throws SQLException {
		Parm parm = new Parm();
		//Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
		parm.setC_MKT(rs.getString("C_MKT"));
		parm.setC_BRND(rs.getString("C_BRND"));
		parm.setI_MOD_YR(rs.getString("I_MOD_YR"));
		parm.setC_BODY_MODEL(rs.getString("C_BODY_MODEL"));
		parm.setC_ENGINE_SC(rs.getString("C_ENGINE_SC"));
		parm.setC_TRANS_SC(rs.getString("C_TRANS_SC"));
		parm.setC_DLR(rs.getString("C_DLR"));
		parm.setC_ZONE(rs.getString("C_ZONE"));
		parm.setC_LANG(rs.getString("C_LANG"));
		parm.setQ_MIS(rs.getString("Q_MIS"));
		parm.setL_ELIG(rs.getString("L_ELIG"));
		parm.setL_REC_STAT(rs.getString("L_REC_STAT"));
		parm.setX_MSG(rs.getString("X_MSG"));
		parm.setD_STMP_EFF_STRT(rs.getString("D_STMP_EFF_STRT"));
		parm.setD_STMP_EFF_END(rs.getString("D_STMP_EFF_END"));
		parm.setC_LOP12(rs.getString("C_LOP12"));
		parm.setC_LOP34(rs.getString("C_LOP34"));
		parm.setC_LOP56(rs.getString("C_LOP56"));
		parm.setC_LOP78(rs.getString("C_LOP78"));
		//parm.setUpdateTimestamp(currentTimestamp);
		parm.setExceptionMsg(this.exception!=null?"!!Duplicate Keys!!":"isNotDuplicate");
		return parm;
	}

}
