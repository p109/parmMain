package com.parm.controller;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.parm.entity.Parm;
import com.parm.service.ParmService;
import com.parm.util.LoginSecurityJwt;

@Controller
public class ParmController {

	@Autowired
	ParmService parmservice;
	@Autowired
	LoginSecurityJwt loginSecurityJwt;

	String Flag = "";

	private static Logger logger = LogManager.getLogger(ParmController.class);

	@RequestMapping("/")
	public String getUserAuthorization(javax.servlet.http.HttpServletRequest request) {

		String userid = "T0088PY";
		Flag = parmservice.getUser(userid);
		request.setAttribute("flag", Flag);
		System.out.println(request.getAttribute("flag"));
		Flag = Flag.trim();
		if (Flag.isEmpty()) {
			return "User";
		}
		return "redirect:/Parm";
	}

	@RequestMapping("/Parm")
	public String Frontend() {
		logger.debug("parm url");
		return "Parm";
	}

	@RequestMapping("/Select")
	@ResponseBody
	public List<Parm> getAllParms() {
		logger.debug("Select Operation Inside");
		return parmservice.getAllParms(null);
	}

	@PostMapping(value = "/Insert")
	@ResponseBody
	public List<Parm> InsertParms(@RequestBody Parm parm) {
		logger.debug("Insert Operation Inside");
		List<Parm> parm1 = parmservice.InsertParms(parm);
		return parm1;
	}

	@PostMapping(value = "/Update")
	@ResponseBody
	public List<Parm> UpdateParms(@RequestBody List<Parm> parm) {
		logger.debug("Update Operation Inside");
		return parmservice.UpdateParms(parm);
	}

	@DeleteMapping(value = "/Delete")
	@ResponseBody
	public List<Parm> DeleteParms(@RequestBody Parm parm) {
		logger.debug("Delete Operation Inside");
		return parmservice.DeleteParms(parm);
	}
}
