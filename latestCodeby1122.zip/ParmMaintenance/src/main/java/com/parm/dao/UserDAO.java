package com.parm.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.parm.entity.User;

public interface UserDAO extends JpaRepository<User, String>,CrudRepository<User, String> {

}
