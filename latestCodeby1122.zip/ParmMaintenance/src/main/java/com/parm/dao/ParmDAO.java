package com.parm.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.parm.entity.Parm;

public interface ParmDAO extends JpaRepository<Parm, String>,CrudRepository<Parm, String>{

}
