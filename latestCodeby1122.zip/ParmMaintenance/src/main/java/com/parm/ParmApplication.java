package com.parm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParmApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParmApplication.class, args);
	}

}
