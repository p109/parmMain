package com.parm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name = "DIDI_USER")
public class User{

	@Id
	@Column
	String USER_ID;
	@Column
	String USER_FIRST_NAME;
	@Column
	String USER_LAST_NAME;
	@Column
	String USER_EMAIL;
	@Column
	String USER_ACCESS;
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public User(String uSER_ID, String uSER_FIRST_NAME, String uSER_LAST_NAME, String uSER_EMAIL, String uSER_ACCESS) {
		super();
		USER_ID = uSER_ID;
		USER_FIRST_NAME = uSER_FIRST_NAME;
		USER_LAST_NAME = uSER_LAST_NAME;
		USER_EMAIL = uSER_EMAIL;
		USER_ACCESS = uSER_ACCESS;
	}

	public String getUSER_ID() {
		return USER_ID;
	}
	public void setUSER_ID(String uSER_ID) {
		USER_ID = uSER_ID;
	}
	public String getUSER_FIRST_NAME() {
		return USER_FIRST_NAME;
	}
	public void setUSER_FIRST_NAME(String uSER_FIRST_NAME) {
		USER_FIRST_NAME = uSER_FIRST_NAME;
	}
	public String getUSER_LAST_NAME() {
		return USER_LAST_NAME;
	}
	public void setUSER_LAST_NAME(String uSER_LAST_NAME) {
		USER_LAST_NAME = uSER_LAST_NAME;
	}
	public String getUSER_EMAIL() {
		return USER_EMAIL;
	}
	public void setUSER_EMAIL(String uSER_EMAIL) {
		USER_EMAIL = uSER_EMAIL;
	}
	public String getUSER_ACCESS() {
		return USER_ACCESS;
	}
	public void setUSER_ACCESS(String uSER_ACCESS) {
		USER_ACCESS = uSER_ACCESS;
	}
	@Override
	public String toString() {
		return "UserEntity [USER_ID=" + USER_ID + ", USER_FIRST_NAME=" + USER_FIRST_NAME + ", USER_LAST_NAME="
				+ USER_LAST_NAME + ", USER_EMAIL=" + USER_EMAIL + ", USER_ACCESS=" + USER_ACCESS + "]";
	}
	
	
	
}
