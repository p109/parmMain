package com.parm.entity;

import javax.persistence.*;

@Entity(name = "SDIDPARM")
public class Parm {

	@Id
	@Column
	String C_MKT;
	@Column
	String C_BRND;
	@Column
	String I_MOD_YR;
	@Column
	String C_BODY_MODEL;
	@Column
	String C_ENGINE_SC;
	@Column
	String C_TRANS_SC;
	@Column
	String C_DLR;
	@Column
	String C_ZONE;
	@Column
	String C_LANG;
	@Column
	String Q_MIS;
	@Column
	String L_ELIG;
	@Column
	String L_REC_STAT;
	@Column
	String X_MSG;
	@Column
	String D_STMP_EFF_STRT;
	@Column
	String D_STMP_EFF_END;
	@Column
	String C_LOP12;
	@Column
	String C_LOP34;
	@Column
	String C_LOP56;
	@Column
	String C_LOP78;
//	@Transient
//	Timestamp updateTimestamp;
	@Transient
	String exceptionMsg;
	

	public Parm() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Parm(String c_MKT, String c_BRND, String i_MOD_YR, String c_BODY_MODEL, String c_ENGINE_SC,
			String c_TRANS_SC, String c_DLR, String c_ZONE, String c_LANG, String q_MIS, String l_ELIG,
			String l_REC_STAT, String x_MSG, String d_STMP_EFF_STRT, String d_STMP_EFF_END, String c_LOP12,
			String c_LOP34, String c_LOP56, String c_LOP78, String exceptionMsg) {
		super();
		C_MKT = c_MKT;
		C_BRND = c_BRND;
		I_MOD_YR = i_MOD_YR;
		C_BODY_MODEL = c_BODY_MODEL;
		C_ENGINE_SC = c_ENGINE_SC;
		C_TRANS_SC = c_TRANS_SC;
		C_DLR = c_DLR;
		C_ZONE = c_ZONE;
		C_LANG = c_LANG;
		Q_MIS = q_MIS;
		L_ELIG = l_ELIG;
		L_REC_STAT = l_REC_STAT;
		X_MSG = x_MSG;
		D_STMP_EFF_STRT = d_STMP_EFF_STRT;
		D_STMP_EFF_END = d_STMP_EFF_END;
		C_LOP12 = c_LOP12;
		C_LOP34 = c_LOP34;
		C_LOP56 = c_LOP56;
		C_LOP78 = c_LOP78;
		this.exceptionMsg = exceptionMsg;
	}


	public String getC_MKT() {
		return C_MKT;
	}


	public void setC_MKT(String c_MKT) {
		C_MKT = c_MKT;
	}


	public String getC_BRND() {
		return C_BRND;
	}


	public void setC_BRND(String c_BRND) {
		C_BRND = c_BRND;
	}


	public String getI_MOD_YR() {
		return I_MOD_YR;
	}


	public void setI_MOD_YR(String i_MOD_YR) {
		I_MOD_YR = i_MOD_YR;
	}


	public String getC_BODY_MODEL() {
		return C_BODY_MODEL;
	}


	public void setC_BODY_MODEL(String c_BODY_MODEL) {
		C_BODY_MODEL = c_BODY_MODEL;
	}


	public String getC_ENGINE_SC() {
		return C_ENGINE_SC;
	}


	public void setC_ENGINE_SC(String c_ENGINE_SC) {
		C_ENGINE_SC = c_ENGINE_SC;
	}


	public String getC_TRANS_SC() {
		return C_TRANS_SC;
	}


	public void setC_TRANS_SC(String c_TRANS_SC) {
		C_TRANS_SC = c_TRANS_SC;
	}


	public String getC_DLR() {
		return C_DLR;
	}


	public void setC_DLR(String c_DLR) {
		C_DLR = c_DLR;
	}


	public String getC_ZONE() {
		return C_ZONE;
	}


	public void setC_ZONE(String c_ZONE) {
		C_ZONE = c_ZONE;
	}


	public String getC_LANG() {
		return C_LANG;
	}


	public void setC_LANG(String c_LANG) {
		C_LANG = c_LANG;
	}


	public String getQ_MIS() {
		return Q_MIS;
	}


	public void setQ_MIS(String q_MIS) {
		Q_MIS = q_MIS;
	}


	public String getL_ELIG() {
		return L_ELIG;
	}


	public void setL_ELIG(String l_ELIG) {
		L_ELIG = l_ELIG;
	}


	public String getL_REC_STAT() {
		return L_REC_STAT;
	}


	public void setL_REC_STAT(String l_REC_STAT) {
		L_REC_STAT = l_REC_STAT;
	}


	public String getX_MSG() {
		return X_MSG;
	}


	public void setX_MSG(String x_MSG) {
		X_MSG = x_MSG;
	}


	public String getD_STMP_EFF_STRT() {
		return D_STMP_EFF_STRT;
	}


	public void setD_STMP_EFF_STRT(String d_STMP_EFF_STRT) {
		D_STMP_EFF_STRT = d_STMP_EFF_STRT;
	}


	public String getD_STMP_EFF_END() {
		return D_STMP_EFF_END;
	}


	public void setD_STMP_EFF_END(String d_STMP_EFF_END) {
		D_STMP_EFF_END = d_STMP_EFF_END;
	}


	public String getC_LOP12() {
		return C_LOP12;
	}


	public void setC_LOP12(String c_LOP12) {
		C_LOP12 = c_LOP12;
	}


	public String getC_LOP34() {
		return C_LOP34;
	}


	public void setC_LOP34(String c_LOP34) {
		C_LOP34 = c_LOP34;
	}


	public String getC_LOP56() {
		return C_LOP56;
	}


	public void setC_LOP56(String c_LOP56) {
		C_LOP56 = c_LOP56;
	}


	public String getC_LOP78() {
		return C_LOP78;
	}


	public void setC_LOP78(String c_LOP78) {
		C_LOP78 = c_LOP78;
	}


	public String getExceptionMsg() {
		return exceptionMsg;
	}


	public void setExceptionMsg(String exceptionMsg) {
		this.exceptionMsg = exceptionMsg;
	}


	@Override
	public String toString() {
		return "Parm [C_MKT=" + C_MKT + ", C_BRND=" + C_BRND + ", I_MOD_YR=" + I_MOD_YR + ", C_BODY_MODEL="
				+ C_BODY_MODEL + ", C_ENGINE_SC=" + C_ENGINE_SC + ", C_TRANS_SC=" + C_TRANS_SC + ", C_DLR=" + C_DLR
				+ ", C_ZONE=" + C_ZONE + ", C_LANG=" + C_LANG + ", Q_MIS=" + Q_MIS + ", L_ELIG=" + L_ELIG
				+ ", L_REC_STAT=" + L_REC_STAT + ", X_MSG=" + X_MSG + ", D_STMP_EFF_STRT=" + D_STMP_EFF_STRT
				+ ", D_STMP_EFF_END=" + D_STMP_EFF_END + ", C_LOP12=" + C_LOP12 + ", C_LOP34=" + C_LOP34 + ", C_LOP56="
				+ C_LOP56 + ", C_LOP78=" + C_LOP78 + ", exceptionMsg=" + exceptionMsg + "]";
	}


	
}
