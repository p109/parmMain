package com.parm.service;

import java.util.List;
import java.util.Optional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;
import com.parm.dao.ParmDAO;
import com.parm.dao.UserDAO;
import com.parm.entity.Parm;
import com.parm.entity.User;
import com.parm.dto.*;

@Service
public class ParmServiceImpl implements ParmService {

	@Autowired
	ParmDAO parmDao;

	@Autowired
	NamedParameterJdbcTemplate jdbcTemplate;

	@Autowired
	JdbcTemplate jdbcTemplate1;

	@Autowired
	UserDAO userDAO;

	private static Logger logger = LogManager.getLogger(ParmServiceImpl.class);

	@Override
	public String getUser(String userId) {
		boolean res = userDAO.existsById(userId);
		if (res == true) {
			Optional<User> list = userDAO.findById(userId);
			return (list.get().getUSER_ACCESS());
		} else {
			return "";
		}
	}

	@Override
	public List<Parm> getAllParms(String exception) {
		logger.debug("Select query method inside");
		// String sqlQuery = "select * from parm where status = 'A' order by instant
		// DESC"; sorting based on timestamp if this is the first column timestamp
		String sqlQuery = "select * from SDIDPARM where L_REC_STAT = 'A'";
		List<Parm> parmList = jdbcTemplate.query(sqlQuery, new ParmDTO("", exception));
		logger.debug("Select query executed");
		return parmList;

	}

	@Override
	public List<Parm> InsertParms(Parm parm) {

		logger.debug("Insert query method inside");
		String MARKET = parm.getC_MKT().toUpperCase();
		String BRAND = parm.getC_BRND().toUpperCase();
		String YEAR = parm.getI_MOD_YR().toUpperCase();
		String BODY_MODEL = parm.getC_BODY_MODEL().toUpperCase();
		String ENG_SC = parm.getC_ENGINE_SC().toUpperCase();
		String TRANS_SC = parm.getC_TRANS_SC().toUpperCase();
		String Dealer = parm.getC_DLR().toUpperCase();// dealerCode
		String ZONE1 = parm.getC_ZONE().toUpperCase();// dealerZone
		String LANG = parm.getC_LANG().toUpperCase();
		String MIS = parm.getQ_MIS().toUpperCase();
		String FLAG = parm.getL_ELIG().toUpperCase();
		String STATUS = "A";
		String ESD = parm.getD_STMP_EFF_STRT();
		String EED = parm.getD_STMP_EFF_END();
		String MSG = parm.getX_MSG().toUpperCase();
		String LOP1_2 = parm.getC_LOP12().toUpperCase();
		String LOP3_4 = parm.getC_LOP34().toUpperCase();
		String LOP5_6 = parm.getC_LOP56().toUpperCase();
		String LOP7_8 = parm.getC_LOP78().toUpperCase();

		// Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
//		ESD = ConvertDateIntoFormatMM_DD_YYYY(ESD);
//		System.out.println(ESD);

		if (MARKET == null) {
			MARKET = "";
		}
		if (BRAND == null) {
			BRAND = "";
		}
		if (YEAR == null) {
			YEAR = "";
		}
		if (BODY_MODEL == null) {
			BODY_MODEL = "";
		}
		if (ENG_SC == null) {
			ENG_SC = "";
		}
		if (TRANS_SC == null) {
			TRANS_SC = "";
		}
		if (Dealer == null) {
			Dealer = "";
		}
		if (ZONE1 == null) {
			ZONE1 = "";
		}
		if (LANG == null) {
			LANG = "";
		}
		if (MIS == null) {
			MIS = "";
		}
		if (FLAG == null) {
			FLAG = "";
		}
		if (MSG == null) {
			MSG = "";
		}
		if (ESD == null) {
			ESD = "";
		}
		if (EED == null) {
			EED = "";
		}
		if (LOP1_2 == null) {
			LOP1_2 = "";
		}
		if (LOP3_4 == null) {
			LOP3_4 = "";
		}
		if (LOP5_6 == null) {
			LOP5_6 = "";
		}
		if (LOP7_8 == null) {
			LOP7_8 = "";
		}

//		String sqlQuery = "insert into parm (MARKET,BRAND,MODEL_YEAR,BODY_MODEL,ENG_SC,TRANS_SC,DEALER,ZONE1, MIS,ELIG_FLAG,STATUS,MESSAGE,EFFECTIVE_START_DATE,EFFECTIVE_END_DATE,LOP1_2,LOP3_4,LOP5_6,LOP7_8,instant)"
//				+ "VALUES('" + MARKET + "','" + BRAND + "','" + YEAR + "','" + BODY_MODEL + "','" + ENG_SC + "','"
//				+ TRANS_SC + "','" + Dealer + "','" + ZONE1 + "','" + MIS + "','" + FLAG + "','" + STATUS + "','" + MSG
//				+ "','" + ESD + "','" + EED + "','" + LOP1_2 + "','" + LOP3_4 + "','" + LOP5_6 + "','" + LOP7_8 + "','"+currentTimestamp+"')";
//		
//		
		String sqlQuery = "insert into SDIDPARM (C_MKT,C_BRND,I_MOD_YR,C_BODY_MODEL,C_ENGINE_SC,C_TRANS_SC,C_DLR,C_ZONE, Q_MIS,L_ELIG,L_REC_STAT,X_MSG,D_STMP_EFF_STRT,D_STMP_EFF_END,C_LOP12,C_LOP34,C_LOP56,C_LOP78,C_LANG)"
				+ "VALUES('" + MARKET + "','" + BRAND + "','" + YEAR + "','" + BODY_MODEL + "','" + ENG_SC + "','"
				+ TRANS_SC + "','" + Dealer + "','" + ZONE1 + "','" + MIS + "','" + FLAG + "','" + STATUS + "','" + MSG
				+ "','" + ESD + "','" + EED + "','" + LOP1_2 + "','" + LOP3_4 + "','" + LOP5_6 + "','" + LOP7_8 + "','"
				+ LANG + "')";

		String excMsg = null;
		try {
			jdbcTemplate1.execute(sqlQuery);

		} catch (Exception e) {
			logger.debug("Exception(InsertQuery) : " + e.getMessage());
			excMsg = e.getMessage();
		}
		return getAllParms(excMsg);
	}

	@Override
	public List<Parm> UpdateParms(List<Parm> parm) {
		logger.debug("Update query method inside");
		Parm parm1 = parm.get(0);// previous records update with status U
		Parm parm2 = parm.get(1);// updated records insert with new Records
		int count = 0;

		String MARKET1 = parm2.getC_MKT().toUpperCase();
		String BRAND1 = parm2.getC_BRND().toUpperCase();
		String YEAR1 = parm2.getI_MOD_YR().toUpperCase();
		String BODY_MODEL1 = parm2.getC_BODY_MODEL().toUpperCase();
		String ENG_SC1 = parm2.getC_ENGINE_SC().toUpperCase();
		String TRANS_SC1 = parm2.getC_TRANS_SC().toUpperCase();
		String Dealer1 = parm2.getC_DLR().toUpperCase();
		String ZONE11 = parm2.getC_ZONE().toUpperCase();
		String LANG1 = parm2.getC_LANG().toUpperCase();
		String MIS1 = parm2.getQ_MIS().toUpperCase();
		String FLAG1 = parm2.getL_ELIG().toUpperCase();
		String STATUS1 = "A";
		String MSG1 = parm2.getX_MSG().toUpperCase();
		String ESD1 = parm2.getD_STMP_EFF_STRT();
		String EED1 = parm2.getD_STMP_EFF_END();
		String LOP1_21 = parm2.getC_LOP12().toUpperCase();
		String LOP3_41 = parm2.getC_LOP34().toUpperCase();
		String LOP5_61 = parm2.getC_LOP56().toUpperCase();
		String LOP7_81 = parm2.getC_LOP78().toUpperCase();

		String excMsg = null;

		if (MARKET1 == null) {
			MARKET1 = "";
		}
		if (BRAND1 == null) {
			BRAND1 = "";
		}
		if (YEAR1 == null) {
			YEAR1 = "";
		}
		if (BODY_MODEL1 == null) {
			BODY_MODEL1 = "";
		}
		if (ENG_SC1 == null) {
			ENG_SC1 = "";
		}
		if (TRANS_SC1 == null) {
			TRANS_SC1 = "";
		}
		if (Dealer1 == null) {
			Dealer1 = "";
		}
		if (ZONE11 == null) {
			ZONE11 = "";
		}
		if (LANG1 == null) {
			LANG1 = "";
		}
		if (MIS1 == null) {
			MIS1 = "";
		}
		if (FLAG1 == null) {
			FLAG1 = "";
		}
		if (MSG1 == null) {
			MSG1 = "";
		}
		if (ESD1 == null) {
			ESD1 = "";
		}
		if (EED1 == null) {
			EED1 = "";
		}
		if (LOP1_21 == null) {
			LOP1_21 = "";
		}
		if (LOP3_41 == null) {
			LOP3_41 = "";
		}
		if (LOP5_61 == null) {
			LOP5_61 = "";
		}
		if (LOP7_81 == null) {
			LOP7_81 = "";
		}

		String sqlQuery2 = "insert into SDIDPARM (C_MKT,C_BRND,I_MOD_YR,C_BODY_MODEL,C_ENGINE_SC,C_TRANS_SC,C_DLR,C_ZONE, Q_MIS,L_ELIG,L_REC_STAT,X_MSG,D_STMP_EFF_STRT,D_STMP_EFF_END,C_LOP12,C_LOP34,C_LOP56,C_LOP78,C_LANG)"
				+ "VALUES('" + MARKET1 + "','" + BRAND1 + "','" + YEAR1 + "','" + BODY_MODEL1 + "','" + ENG_SC1 + "','"
				+ TRANS_SC1 + "','" + Dealer1 + "','" + ZONE11 + "','" + MIS1 + "','" + FLAG1 + "','" + STATUS1 + "','"
				+ MSG1 + "','" + ESD1 + "','" + EED1 + "','" + LOP1_21 + "','" + LOP3_41 + "','" + LOP5_61 + "','"
				+ LOP7_81 + "','" + LANG1 + "')";
		try {
			jdbcTemplate1.execute(sqlQuery2);
			count++;
		} catch (Exception e) {
			logger.debug("Exception(insert(updateRecords) : " + e.getMessage());
			excMsg = e.getMessage();
		}

		String MARKET = parm1.getC_MKT().toUpperCase();
		String BRAND = parm1.getC_BRND().toUpperCase();
		String YEAR = parm1.getI_MOD_YR().toUpperCase();
		String BODY_MODEL = parm1.getC_BODY_MODEL().toUpperCase();
		String ENG_SC = parm1.getC_ENGINE_SC().toUpperCase();
		String TRANS_SC = parm1.getC_TRANS_SC().toUpperCase();
		String Dealer = parm1.getC_DLR().toUpperCase();
		String ZONE1 = parm1.getC_ZONE().toUpperCase();
		String LANG = parm1.getC_LANG().toUpperCase();
		String MIS = parm1.getQ_MIS().toUpperCase();
		String LOP1_2 = parm1.getC_LOP12().toUpperCase();
		String LOP3_4 = parm1.getC_LOP34().toUpperCase();
		String LOP5_6 = parm1.getC_LOP56().toUpperCase();
		String LOP7_8 = parm1.getC_LOP78().toUpperCase();
		String ESD = parm1.getD_STMP_EFF_STRT();
		String EED = parm1.getD_STMP_EFF_END();

		// String sqlQuery1 = "update parm set status = 'U' where brand = '" + ids +
		// "'";
		// String sqlQyery1 = "update parm set status = 'U' where brand='"+BRAND+"' AND
		// market ='"+MARKET+"' AND model_year ='"+YEAR+"' AND body_model
		// ='"+BODY_MODEL+"' AND eng_sc ='"+ENG_SC+"' AND trans_sc ='"+TRANS_SC+"' AND
		// dealer ='"+Dealer+"' AND zone1 ='"+ZONE1+"' AND mis ='"+MIS+"'AND lop1_2
		// ='"+LOP1_2+"' AND lop3_4 ='"+LOP3_4+"' AND lop5_6 ='"+LOP5_6+"' AND lop7_8
		// ='"+LOP7_8+"'";
		String sqlQyery1 = "update SDIDPARM set L_REC_STAT = 'U' where c_BRND='" + BRAND + "' AND C_MKT ='" + MARKET
				+ "' AND I_MOD_YR ='" + YEAR + "' AND C_BODY_MODEL ='" + BODY_MODEL + "' AND C_ENGINE_SC ='" + ENG_SC
				+ "' AND C_TRANS_SC ='" + TRANS_SC + "' AND C_DLR ='" + Dealer + "' AND C_ZONE ='" + ZONE1
				+ "' AND Q_MIS ='" + MIS + "'AND  C_LOP12 ='" + LOP1_2 + "' AND C_LOP34 ='" + LOP3_4
				+ "' AND C_LOP56 ='" + LOP5_6 + "' AND C_LOP78 ='" + LOP7_8 + "' AND D_STMP_EFF_STRT ='" + ESD
				+ "'AND D_STMP_EFF_END ='" + EED + "' AND C_LANG ='" + LANG + "'";

		if (count > 0) {
			try {
				jdbcTemplate1.update(sqlQyery1);
			} catch (Exception e) {
				logger.debug("Exception(Update(updateRecords) : " + e.getMessage());
				excMsg = e.getMessage();
			}
		}
		count = 0;
		return getAllParms(excMsg);

	}

	@Override
	public List<Parm> DeleteParms(Parm parm) {

		String MARKET = parm.getC_MKT();
		String BRAND = parm.getC_BRND();
		String YEAR = parm.getI_MOD_YR();
		String BODY_MODEL = parm.getC_BODY_MODEL();
		String ENG_SC = parm.getC_ENGINE_SC();
		String TRANS_SC = parm.getC_TRANS_SC();
		String Dealer = parm.getC_DLR();
		String ZONE1 = parm.getC_ZONE();
		String LANG = parm.getC_LANG();
		String MIS = parm.getQ_MIS();
		String LOP1_2 = parm.getC_LOP12();
		String LOP3_4 = parm.getC_LOP34();
		String LOP5_6 = parm.getC_LOP56();
		String LOP7_8 = parm.getC_LOP78();
		String ESD = parm.getD_STMP_EFF_STRT();
		String EED = parm.getD_STMP_EFF_END();

		// String sqlQuery = "update parm set status = 'D' where brand='"+BRAND+"'AND
		// market ='"+MARKET+"'&& model_year = '"+YEAR+"'";
		// String sqlQyery1 = "update parm set status = 'D' where brand='"+BRAND+"' AND
		// market ='"+MARKET+"' AND model_year ='"+YEAR+"' AND body_model
		// ='"+BODY_MODEL+"' AND eng_sc ='"+ENG_SC+"' AND trans_sc ='"+TRANS_SC+"' AND
		// dealer ='"+Dealer+"' AND zone1 ='"+ZONE1+"' AND mis ='"+MIS+"'AND lop1_2
		// ='"+LOP1_2+"' AND lop3_4 ='"+LOP3_4+"' AND lop5_6 ='"+LOP5_6+"' AND lop7_8
		// ='"+LOP7_8+"'";
		String sqlQyery1 = "update SDIDPARM set L_REC_STAT = 'D' where C_BRND='" + BRAND + "' AND C_MKT ='" + MARKET
				+ "' AND I_MOD_YR ='" + YEAR + "' AND C_BODY_MODEL ='" + BODY_MODEL + "' AND C_ENGINE_SC ='" + ENG_SC
				+ "' AND C_TRANS_SC ='" + TRANS_SC + "' AND C_DLR ='" + Dealer + "' AND C_ZONE ='" + ZONE1
				+ "' AND Q_MIS ='" + MIS + "'AND  C_LOP12 ='" + LOP1_2 + "' AND C_LOP34 ='" + LOP3_4
				+ "' AND C_LOP56 ='" + LOP5_6 + "' AND C_LOP78 ='" + LOP7_8 + "' AND D_STMP_EFF_STRT ='" + ESD
				+ "' AND D_STMP_EFF_END ='" + EED + "'AND C_LANG ='" + LANG + "'";

		jdbcTemplate1.update(sqlQyery1);
		logger.debug("Exception(Delete()");
		return getAllParms(null);
	}

	public String ConvertDateIntoFormatMM_DD_YYYY(String date1) {
		// 01/01/1999---MM/DD/YYYY
		// YYYY-MM-DD
		System.out.println(date1);
		String str1yyyy = date1.substring(0, 4);
		String str2mm = date1.substring(5, 7);
		String str3dd = date1.substring(8, 10);

		String ansmmddyy = str2mm.concat("-").concat(str3dd).concat("-").concat(str1yyyy);
		System.out.println(ansmmddyy);
		return ansmmddyy;

	}

}
