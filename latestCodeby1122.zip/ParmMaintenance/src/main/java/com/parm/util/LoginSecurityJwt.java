package com.parm.util;

import java.util.Base64;
import java.util.Map;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class LoginSecurityJwt {
	@SuppressWarnings("unchecked")
	public String getUserId(String jwtToken) throws JsonMappingException, JsonProcessingException {
		String[] split_string = jwtToken.split("\\.");
		String base64EncodedHeader = split_string[0];
		base64EncodedHeader = base64EncodedHeader.replace("Bearer ", "");
		String base64EncodedBody = split_string[1];

		byte[] decodedBytes = Base64.getDecoder().decode(base64EncodedBody);
		String body = new String(decodedBytes);

		ObjectMapper mapper = new ObjectMapper();
		Map<String, String> map = mapper.readValue(body, Map.class);
		String userId = map.get("sub");
		return userId;

	}
}
