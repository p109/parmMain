DROP TABLE IF EXISTS SDIDPARM;
CREATE TABLE SDIDPARM (

   C_MKT CHAR(1) not null,
   C_BRND VARCHAR(25) not null,
   I_MOD_YR VARCHAR(4) not null,
   C_BODY_MODEL CHAR(6) not null,
   C_ENGINE_SC CHAR(3) not null,
   C_TRANS_SC CHAR(3) not null ,
   C_DLR CHAR(5) not null,
   C_ZONE CHAR(2) not null,
   C_LANG CHAR(3) not null,
   Q_MIS INT,
   L_ELIG  CHAR(1) not null,
   L_REC_STAT varchar(1) not null,
   X_MSG VARCHAR(500),
   D_STMP_EFF_STRT DATE,
   D_STMP_EFF_END DATE,
   I_LOGON_ADD VARCHAR(100),
   C_LOP12 VARCHAR(2) not null,
   C_LOP34 VARCHAR(2) not null,
   C_LOP56 VARCHAR(2) not null,
   C_LOP78 VARCHAR(2) not null,
   instant timestamp default current_timestamp,
   
   CONSTRAINT SDIDPARM PRIMARY KEY(C_MKT, C_BRND, I_MOD_YR, C_BODY_MODEL, C_ENGINE_SC, C_TRANS_SC, C_DLR, C_ZONE,C_LANG,Q_MIS,C_LOP12,C_LOP34
   ,C_LOP56,C_LOP78, D_STMP_EFF_STRT, D_STMP_EFF_END)
  
);

DROP TABLE IF EXISTS DIDI_USER;
CREATE TABLE DIDI_USER (
	USER_ID VARCHAR (80) NOT NULL PRIMARY KEY,
	USER_FIRST_NAME VARCHAR(80) NOT NULL,
	USER_LAST_NAME VARCHAR(80) NOT NULL,
	USER_EMAIL VARCHAR(100) NOT NULL,
	USER_ACCESS VARCHAR(1),
	instant timestamp default current_timestamp
);


