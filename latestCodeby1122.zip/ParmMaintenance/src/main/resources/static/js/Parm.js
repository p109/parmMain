$(document).ready(function() {

	var myTable;
	var data;
	var selectedData;
	fetchTableData("http://localhost:8080/Select");
	
	var insertParmElements = 
	
	[         				    "#MARKETInsertInput","#BRANDInsertInput","#MODEL_YEARInsertInput","#BODY_MODELInsertInput",
	                            "#ENG_SCInsertInput","#TRANS_SCInsertInput","#DEALERInsertInput","#ZONEInsertInput",
	                            "#LangInsertInput",
	                            "#MISInsertInput","#ELIG_FLAGInsertInput","#STATUSInsertInput","#MESSAGEInsertInput",
								"#EFFECTIVE_START_DATEInsertInput","#EFFECTIVE_END_DATEInsertInput",
								"#LOP1_2InsertInput","#LOP3_4InsertInput","#LOP5_6InsertInput","#LOP7_8InsertInput"
    ];
	
	var updateParmElements = 
	
	[							"#MARKETupdateOld","#BRANDupdateOld","#MODEL_YEARupdateOld","#BODY_MODELupdateOld",
								"#ENG_SCupdateOld","#TRANS_SCupdateOld","#DEALERupdateOld","#ZONEupdateOld",
								"#LangupdateOld",
								"#MISupdateOld","#ELIG_FLAGupdateOld","#STATUSupdateOld","#MESSAGEupdateOld",
								"#EFFECTIVE_START_DATEupdateOld","#EFFECTIVE_END_DATEupdateOld",
								"#LOP1_2updateOld","#LOP3_4updateOld","#LOP5_6updateOld","#LOP7_8updateOld"
    ];
	
	
	var copyParmElements = 
	
	[						"#MARKETupdateNew","#BRANDupdateNew","#MODEL_YEARupdateNew","#BODY_MODELupdateNew", 
							"#ENG_SCupdateNew","#TRANS_SCupdateNew","#DEALERupdateNew","#ZONEupdateNew", 
							"#LangupdateNew",
							"#MISupdateNew","#ELIG_FLAGupdateNew","#STATUSupdateNew","#MESSAGEupdateNew",
							"#EFFECTIVE_START_DATEupdateNew","#EFFECTIVE_END_DATEupdateNew",
							"#LOP1_2updateNew","#LOP3_4updateNew","#LOP5_6updateNew","#LOP7_8updateNew"
	];
	
	var deleteParmElements = 
	
	[						"#MARKETdeleteOld","#BRANDdeleteOld", "#MODEL_YEARdeleteOld", "#BODY_MODELdeleteOld",
							"#ENG_SCdeleteOld","#TRANS_SCdeleteOld","#DEALERdeleteOld","#ZONEdeleteOld",
							"#LangdeleteOld",
							"#MISdeleteOld","#ELIG_FLAGdeleteOld","#STATUSdeleteOld","#MESSAGEdeleteOld",
							"#EFFECTIVE_START_DATEdeleteOld","#EFFECTIVE_END_DATEdeleteOld",
							"#LOP1_2deleteOld","#LOP3_4deleteOld","#LOP5_6deleteOld","#LOP7_8deleteOld"
	];
	
	var ParmElements = ["c_MKT","c_BRND","i_MOD_YR" ,"c_BODY_MODEL","c_ENGINE_SC","c_TRANS_SC","c_DLR","c_ZONE","c_LANG","q_MIS",
						"l_ELIG","l_REC_STAT","x_MSG","d_STMP_EFF_STRT","d_STMP_EFF_END",
						"c_LOP12","c_LOP34","c_LOP56","c_LOP78"];
	
	
	//Change data on tables
	$('#ParmInsertBtn').on('click', function() {
		var insertData1 = getInputData(ParmElements, insertParmElements);
		
		if(insertData1.c_MKT !=="" && insertData1.c_BRND !=="" && insertData1.i_MOD_YR !=="" && insertData1.c_BODY_MODEL !==""
			&& insertData1.c_ENGINE_SC !=="" && insertData1.c_TRANS_SC !=="" && insertData1.c_DLR !=="" && insertData1.c_ZONE !==""
			&& insertData1.c_LANG !==""  && insertData1.q_MIS !=="" && insertData1.d_STMP_EFF_STRT !=="" && insertData1.d_STMP_EFF_END !==""
			&& insertData1.c_LOP12 !=="" && insertData1.c_LOP34 !=="" &&insertData1.c_LOP56 !==""   && insertData1.c_LOP78 !=="" )
		{
		   if(insertData1.c_MKT ==="u" || insertData1.c_MKT ==="m" || insertData1.c_MKT ==="c" || insertData1.c_MKT ==="i"||
		 		  insertData1.c_MKT ==="U" || insertData1.c_MKT ==="M" || insertData1.c_MKT ==="C" || insertData1.c_MKT ==="I" || insertData1.c_MKT ==="*"){
			if(insertData1.l_ELIG ==="y" || insertData1.l_ELIG ==="n" || insertData1.l_ELIG ==="Y" || insertData1.l_ELIG ==="N"  )
			{
			   
		            document.getElementById('validationalert').style.display='none';
					var insertData = getInputData(ParmElements, insertParmElements);
					postData(insertData,"http://localhost:8080/Insert","POST")
					
			}else{
					document.getElementById("validationalert").innerHTML = "!!Please Enter Correct Values for Eligiblity Flag Y OR N!!";
			}
		   }else{
		      document.getElementById("validationalert").innerHTML = "!!Please Enter Correct Values for Market U OR M OR C OR I!!";
		   }
			
		}else{
			document.getElementById("validationalert").innerHTML = "!!Please Enter Mandatory Fileds!!";
		}
	});

	//Show / hide data update input fields
	$('#insertBtn').on('click', function() {
		$('.toggle-div').hide();
			$('#insertParmDesc').show();
	});

	$('#ParmUpdateBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			var updateData = [];
			updateData.push(getInputData(ParmElements, updateParmElements));
			updateData.push(getInputData(ParmElements, copyParmElements));
		if(updateData[1].c_MKT !=="" && updateData[1].c_BRND !=="" && updateData[1].i_MOD_YR !=="" && updateData[1].c_BODY_MODEL !==""
	  		&& updateData[1].c_ENGINE_SC !=="" && updateData[1].c_TRANS_SC !=="" && updateData[1].c_DLR !=="" && updateData[1].c_ZONE !==""
          && updateData[1].c_LANG !=="" 	&& updateData[1].q_MIS !=="" && updateData[1].d_STMP_EFF_STRT !=="" && updateData[1].d_STMP_EFF_END !==""
	  		&& updateData[1].c_LOP12 !=="" && updateData[1].c_LOP34 !=="" &&updateData[1].c_LOP56 !==""   && updateData[1].c_LOP78 !=="" )
		{
          if(updateData[1].c_MKT ==="u" || updateData[1].c_MKT ==="m" || updateData[1].c_MKT ==="c" || updateData[1].c_MKT ==="i" || 
          updateData[1].c_MKT ==="U"    || updateData[1].c_MKT ==="M" 	  || updateData[1].c_MKT ==="C"|| updateData[1].c_MKT ==="I" || updateData[1].c_MKT ==="*"){
  			if(updateData[1].l_ELIG ==="y" || updateData[1].l_ELIG ==="n" || updateData[1].l_ELIG ==="Y" || updateData[1].l_ELIG ==="N"  )
  			{
		 		document.getElementById('validationalert').style.display='none';
		 		postData(updateData, "http://localhost:8080/Update", "POST" );
 			}
  			else{
		 		document.getElementById("validationalert").innerHTML = "!!Please Enter Correct Values for Eligiblity Flag Y OR N!!";
 		 	}
 		  }else{
 		 	    document.getElementById("validationalert").innerHTML = "!!Please Enter Correct Values for Market U OR M OR C OR I!!";
 		  }
		}
		else{
		   document.getElementById("validationalert").innerHTML = "!!Please Enter Mandatory Fileds!!";
		}
		}
	});
	
	$('#updateBtn').on('click', function() {
	   $('.toggle-div').hide();
			$('#updateParmDesc').show();
	});

	$('.copy-btn').on('click', function() {
		copyInputVals(updateParmElements, copyParmElements);
	});
	
	$('#deleteBtn').on('click', function() {
		$('.toggle-div').hide();
			$('#deleteParmDesc').show();
	});
	
	$('#ParmDeleteBtn').on('click', function() {
		if (!jQuery.isEmptyObject(selectedData))
		{
			var deleteData = getInputData(ParmElements, deleteParmElements);
			postData(deleteData, "http://localhost:8080/Delete", "DELETE");
		}
	});
	
	function fetchTableData(url){
        dataType: 'json',
		$.ajax({
			url: url,
			success: function(result) {
				data = result;
				emptyTable();
				updateTable();
			}
		});
	}
	
	function postData(myData,url,method) {
		$.ajax({
			data: JSON.stringify(myData),
			url: url,
			method: method,
			contentType: "application/json",
			success: function(result) {
				data = result;
				if("isNotDuplicate" !== data[0].exceptionMsg){
					document.getElementById("alertMsg").style.display= "block";
					document.getElementById("alertMsg").innerHTML = data[0].exceptionMsg;
				}
				emptyTable();
				updateTable();
			},
			error: function(result) {
				showError(result.responseJSON[0]);
			}
		});
	}
	
	function updateTable() {
			myTable = $('#ParmTable').DataTable({
			  "pageLength": 100,
			  "aaSorting": [[ 1, "desc" ]],
				data: data,
				columns: [
				   //{title: 'TI1MESTAMP',															<td>&nbsp;</td>data: <span></span>'updateTimestamp'},
				     {title:'Effective<br>Start Date<span class = "colorclass">*</span>',			data: 'd_STMP_EFF_STRT'},
				     {title:'Effective<br>End Date<span class = "colorclass">*</span>'  ,			data: 'd_STMP_EFF_END'},
					 {title:'MKT</span><span class = "colorclass">*</span><br>',					data: 'c_MKT'},
				     {title:'BRAND<span class = "colorclass">*</span><br>',							data: 'c_BRND'},
				     {title:'Body<br>Model<span class = "colorclass">*</span>',						data: 'c_BODY_MODEL'},
				     {title:'Model<br>Year<span class = "colorclass">*</span>', 					data: 'i_MOD_YR'},
				     {title:'Engine<br>Sales Code<span class = "colorclass">*</span>',				data: 'c_ENGINE_SC'},
				     {title:'Transmission<br>Sales Code<span class = "colorclass">*</span>',		data: 'c_TRANS_SC'},
				     {title:'Dealer<br>Zone<span class = "colorclass">*</span>',					data: 'c_ZONE'},
				     {title:'Dealer<br>Code<span class = "colorclass">*</span>',					data: 'c_DLR'},
				     {title:'Dealer<br>Langauge<span class = "colorclass">*</span>',				data: 'c_LANG'},
				     {title:'Labor Operation<br>Function Group<span class = "colorclass">*</span>',	data: 'c_LOP12'},
				     {title:'Labor OP<br>Component Group<span class = "colorclass">*</span>',		data: 'c_LOP34'},
				     {title:'Labor Operation<br>Component<span class = "colorclass">*</span>',		data: 'c_LOP56'},
				     {title:'Labor Operation<br>Operation Code<span class = "colorclass">*</span>',	data: 'c_LOP78'},
				     {title:'MIS<span class = "colorclass">*</span><br>',							data: 'q_MIS'},
				     {title:'DIDI Eligibility<br>Flag',												data: 'l_ELIG'},
				   //{title:'Status',																data: 'l_REC_STAT'},
				   	 {title:'DIDI Eligibility<br>Message',											data: 'x_MSG'},
				],
			});
		}
		
		//Row selection
		$('#ParmTable tbody').on( 'click', 'tr', function () {
	        clearInputVals(insertParmElements);
			clearInputVals(updateParmElements);
			clearInputVals(deleteParmElements);
	        //if row was selected, unselect
			if ( $(this).hasClass('selected') ) {
	            $(this).removeClass('selected');
	          
	        }
	        else {
	            //disable all selections, then select row
	        	myTable.$('tr.selected').removeClass('selected');
	            $(this).addClass('selected');
	            selectedData = myTable.row(this).data();
	            setInputVals(selectedData, ParmElements, updateParmElements);
	            setInputVals(selectedData, ParmElements, deleteParmElements);
	            setInputVals(selectedData, ParmElements, insertParmElements);
	        }
	    } );
	    
	    
	    
	    
			
	function emptyTable() {
		clearInputVals(deleteParmElements);
		clearInputVals(updateParmElements);
		clearInputVals(copyParmElements);
		clearInputVals(insertParmElements);
		selectedData = {};
		
		if (myTable != null)
		{
			$('#ParmTable tbody').unbind('click');
			
			myTable.destroy();
		}
		
		$('.waBody').empty();
		$('.waHead').empty();
	}
	
	
});